# MLBB Academy

Website tutorial Mikro dan Makro Mobile Legends: Bang Bang.

## Menjalankan secara lokal
Buka `index.html` menggunakan browser.

## Deploy ke GitHub Pages
1. Buat repository baru di GitHub, misalnya `mlbb-academy`.
2. Upload `index.html` ke direktori utama (root) repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
6. Tunggu proses publikasi selesai. GitHub akan menampilkan URL website di bagian Pages.

## Catatan
- Website ini berupa HTML, CSS, dan JavaScript statis; tidak memerlukan server atau database.
- Jika nama repository bukan `<username>.github.io`, URL umumnya berbentuk `https://<username>.github.io/<nama-repository>/`.
- Ini adalah proyek fan-made dan bukan situs resmi atau afiliasi Moonton.
